<template>
  <div class="dealer-info">
     
      <ul>
          <li>
              
          </li>
      </ul>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

ul {
    background: #fff;
    padding: 0 9px;
}

</style>